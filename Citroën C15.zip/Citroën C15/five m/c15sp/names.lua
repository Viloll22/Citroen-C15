Citizen.CreateThread(function()
	AddTextEntry('C15SP', 'c15sp')
end)